package com.example.label;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashMap;

public class Register extends AppCompatActivity {
    Button btnregister;
    ProgressDialog progressDialog;
    EditText edtemail,edtphone,edtpass,edtconfpass;
    FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        auth = FirebaseAuth.getInstance();
        btnregister = (Button) findViewById(R.id.btnregister);
        edtemail = (EditText) findViewById(R.id.edtemail);
        edtphone = (EditText) findViewById(R.id.edtphone);
        edtpass = (EditText) findViewById(R.id.edtpass);
        edtconfpass = (EditText) findViewById(R.id.edtconfpass);



        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = edtemail.getText().toString().trim();
                String phone = edtphone.getText().toString().trim();
                String password = edtpass.getText().toString().trim();
                String confirmpassword = edtconfpass.getText().toString().trim();
                String emailPattern = "[_A-Za-z0-9-.?]+@[a-z]+\\.+[a-z]+";
                /*String MobilePattern = "";*/


                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(Register.this,"Please Enter The Email",Toast.LENGTH_SHORT).show();
                    return;
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(Register.this, "Please Enter Your Password",Toast.LENGTH_SHORT).show();
                }else if (TextUtils.isEmpty(confirmpassword)) {
                    Toast.makeText(Register.this, "Please Enter Your Confirm Password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(phone)) {
                    Toast.makeText(Register.this, "Please Enter Your Mobno", Toast.LENGTH_SHORT).show();
                }else if (!confirmpassword.equals(password)) {
                    Toast.makeText(Register.this, "Password Does Not Match",Toast.LENGTH_SHORT).show();
                }else if (!email.matches(emailPattern)) {

                    Toast.makeText(Register.this,"Invalid Email Address", Toast.LENGTH_SHORT).show();
                }else if (phone.length() != 10)/*)*/ {

                    Toast.makeText(getApplicationContext(),"Invalid Mobile Number", Toast.LENGTH_SHORT).show();
                }else if (confirmpassword.length() < 6 && password.length() < 6) {
                    Toast.makeText(Register.this, "Password must be at least 6 characters",Toast.LENGTH_SHORT).show();
                }
                else {
                    //requesting Firebase server
                    showProcessDialog();
                    auth.createUserWithEmailAndPassword(email,password)
                            .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        progressDialog.dismiss();
                                        Toast.makeText(Register.this, "Register failed!",Toast.LENGTH_SHORT).show();
                                    } else {

                                        Toast.makeText(Register.this, "Register successful!",Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(Register.this, Login.class));
                                        progressDialog.dismiss();
                                        finish();
                                    }
                                }
                            });
                }
            }
        });
    }


    private void showProcessDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Registering");
        progressDialog.setMessage("Registering a new account...");
        progressDialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == android.R.id.home) {
            this.finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}